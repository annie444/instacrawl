"""Top-level package for instagram crawler."""
# instacrawl/__init__.py

__app_name__ = "instacrawl"
__version__ = "0.1.4"
