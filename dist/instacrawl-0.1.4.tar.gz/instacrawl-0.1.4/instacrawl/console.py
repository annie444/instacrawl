"""Global console instance."""

from rich.console import Console

console = Console()
