# InstaCrawl

An [Instagram] post crawler focused on optimizing algorithm performance through model classification

## Installation

**With pip**
```bash
pip install instacrawl
```

**From source**
```bash
git clone https://github.com/annie444/instacrawl.git 

cd instacrawl

pip install -r requirements.txt

python instacrawl/__main__.py
```

**NOTE:** InstaCrawl requires [Google Chrome] and [chromedriver] to be installed. The [PyPi] package comes with an installation of [chromedriver], however, 
there is no guarantee that this version of [chromedriver] will be compatible with your version of [Google Chrome].

## Using InstaCrawl

### Setup

Upon launching 




[Google Chrome]: https://www.google.com/chrome/
[chromedriver]: https://chromedriver.chromium.org
[Instagram]: https://instagram.com
[PyPi]: https://pypi.org/project/instacrawl/
